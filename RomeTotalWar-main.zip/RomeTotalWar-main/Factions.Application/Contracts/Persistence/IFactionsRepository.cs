﻿using Factions.Domain.Entities;

namespace Factions.Application.Contracts.Persistence
{
    public interface IFactionsRepository : IGenericRepository<Faction>
    {
    }
}
